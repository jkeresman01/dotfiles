General guidelines
==================

Not much, right now. If you have an idea and some code, just
create a PR, I will gladly review and comment (and, likely, merge)

Just one minor note: ``bumblebee-status`` is mostly a one-person,
spare-time project, so please be patient when answering an issue,
question or PR takes a while.

Also, the (small) community that has gathered around ``bumblebee-status``
is extremely friendly and helpful, so don't hesitate to create issues
with questions, somebody will always come up with a useful answer.

:)
